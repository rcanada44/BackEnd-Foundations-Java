package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.Champion;
import com.example.demo.models.ChampionRepository;

@RestController
@RequestMapping("/champion")
public class ChampionController {

	@Autowired
	ChampionRepository championRepository;
	
	@GetMapping()
	public List<Champion> getChampions(){
		return championRepository.findAll();
	}
	
	@GetMapping("/(id)")
	public ResponseEntity<Object> getChampionById(@PathVariable int id) {
		Champion foundChampion = championRepository.findById(id).orElse(null);
		if(foundChampion == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(foundChampion);
    }
	
	@PostMapping()
	public Champion addChampion(@RequestBody Champion champion) {
		championRepository.save(champion);
		return champion;	
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Champion> removeChampion(@PathVariable int id) {
	Champion foundChampion = championRepository.findById(id).orElse(null);
	if (foundChampion == null) {
		return ResponseEntity.notFound().build();
	}
	championRepository.delete(foundChampion);
	return ResponseEntity.ok(foundChampion);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Champion> updateChampion(@PathVariable int id, @RequestBody Champion champion){
		Champion foundChampion = championRepository.findById(id).orElse(null);
		if (foundChampion == null) {
			return ResponseEntity.notFound().build();
		}
		if(champion.getName() != null) {
			foundChampion.setName(champion.getName());
		}
		championRepository.save(foundChampion);
		return ResponseEntity.ok(foundChampion);
	}
	}
	
	
	
	
	
